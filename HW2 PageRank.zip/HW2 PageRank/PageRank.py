'''
@author: Jowy Tran
TCSS 554: Information Retrieval
HW2: PageRank

'''
import numpy as np
import pandas as pd

def getChunks(theList, chunkSize): #this function reads 3 elements at a time from given list
    for i in range(0, len(theList), chunkSize):
        yield theList[i:i+chunkSize] #yield returns a generator, which is an iterable that can only be iterated once.

#np.set_printoptions(precision=3) #prints up to the precision specified here


""" Read graph.txt file and store chunks of [i,j,k] elements in a list """
file = open('./graph.txt', 'r')
text = file.read()
file.close()
tokens = text.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').split()
#print(tokens)
generator = getChunks(tokens, 3) # see getChunks function above
chunkList = list(generator)


""" Create a dictionary containing unique nodes and their total out-degree edges """
dictionary = {} #java equivalence of hash map
duplicateDict = {}
for i in chunkList:
    key = i[0]
    if key not in dictionary:
        dictionary[key] = 0
    if i[1] not in dictionary: # for the graph.txt files where only 1 is shown
        dictionary[i[1]] = 0
    if i[2] == "1": # checks to see if an out-degree edge exists
        
        if key + "->" + i[1] not in duplicateDict: # solve for case of duplicate [i,j,k=1], make another dictionary containing only k=1
            dictionary[key] += 1
            duplicateDict[key+"->"+i[1]] = 1
'''
print("dictionary = ", dictionary)
print("duplicateDict = ", duplicateDict)
print(dictionary.keys(), "\n")
'''


""" Create the Matrix """
df = pd.DataFrame(columns=dictionary.keys(), index=dictionary.keys(), dtype="double").fillna(0)
for i in chunkList:
    if i[2] == "1":
        df.at[i[1],i[0]] = 1 / dictionary[i[0]]
print("(a) What is the output for Matrix M? Give the matrix:","\n\n\t", "Matrix M:\n", df.round(2),"\n\n")
matrix = df.as_matrix() #convert dataframe to numpy matrix
#print("\tnumpy matrix\n", matrix)


""" Create the Original Rank Vector """
element = []
for i in range(0, len(dictionary)):
    element.append(1 / len(dictionary))
vector = np.matrix(element).T
print("\n(b) What is the original rank vector (rj)?","\n\n\t", "original rank vector:\n", vector, "\n")


""" Power Iteration Method """
power = 0;
prevVector = vector
newVector = np.empty(shape=(len(dictionary),1))  #generalize by making shape=(n,1)
newVector.fill(-1) #initialize vector values to -1 to start while loop
dampFactor = .85
leapProbability = (1- dampFactor) / len(dictionary)

while(np.allclose(prevVector, newVector, rtol=1e-06, atol=1e-06) == 0): #compares prevVector and newVector to a precision of 2 decimal places
    prevVector = vector
    power += 1
    newVector = dampFactor * matrix * vector  +  leapProbability # matrix needs to be on the left side of multiplication: 6x6 * 6x1
    #newVector = matrix * vector# matrix needs to be on the left side of multiplication: 6x6 * 6x1

   # print("..................................................\n")
    #print("prevVector:\n", prevVector, "\n\n", "newVector:  iteration # ", power, "\n", newVector, "\n", sep='')
    vector = newVector

print("..................................................\n")
print("(c) What is the Converged rank vector (R)?", "\n\t", "converged rank vector (precision=6)\n", vector, "\n")
print("(d) How many iterations did it take to get the convergence?", "\n\tnumber of iterations =", power, "\n")
